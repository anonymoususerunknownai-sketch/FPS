/** Standalone, relative-URL WebXDC build of the original Call of Blocky. */
import { defineConfig, mergeConfig } from 'vite';
import base from './vite.config';
export default defineConfig(mergeConfig(base, {
  base: './',
  build: {
    outDir: 'dist-webxdc',
    emptyOutDir: true,
    sourcemap: false,
    target: 'es2022',
    rollupOptions: { input: { webxdc: 'webxdc.html' } },
  },
  define: { 'import.meta.env.VITE_WEBXDC': JSON.stringify('1') },
}));
