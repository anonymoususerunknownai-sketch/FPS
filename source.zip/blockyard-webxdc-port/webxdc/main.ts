/** Dedicated WebXDC entry. Only the real Call of Blocky game is included. */
import { isHandheld } from '../src/platform/settings';
import { Runtime } from '../src/platform/runtime';
import type { GameEntry } from '../src/platform/api/client';
import meta from '../src/games/callofblocky/meta';
const games: GameEntry[] = [{ meta, load: () => import('../src/games/callofblocky/client').then((m) => m.default) }];
const canvas = document.getElementById('view') as HTMLCanvasElement;
const ui = document.getElementById('ui') as HTMLElement;
document.body.classList.toggle('touch-mode', isHandheld());
Runtime.start(canvas, ui, games).catch((err: unknown) => {
  console.error('[Call of Blocky WebXDC]', err);
  const box = document.createElement('div');
  box.className = 'screen';
  const msg = document.createElement('div');
  msg.className = 'error-box';
  msg.textContent = `Could not start Call of Blocky: ${err instanceof Error ? err.message : String(err)}\n\nThis game needs WebGL2, WebAssembly SIMD and module Web Workers.`;
  box.append(msg);
  ui.replaceChildren(box);
});
