/** On a machine with Rust and npm dependencies, build a real engine WebXDC file. */
import { spawnSync } from 'node:child_process';
import { readFileSync, writeFileSync, readdirSync, mkdirSync, renameSync, existsSync } from 'node:fs';
import { join, relative, resolve } from 'node:path';
import { zipSync, strToU8 } from 'fflate';

const root = resolve(import.meta.dirname, '..');
const run = (command, args) => {
  const p = spawnSync(command, args, { cwd: root, stdio: 'inherit', shell: process.platform === 'win32' });
  if (p.status !== 0) process.exit(p.status || 1);
};
run('npm', ['run', 'wasm']);
run('npx', ['vite', 'build', '--config', 'vite.webxdc.config.ts']);
const dist = join(root, 'dist-webxdc');
const html = join(dist, 'webxdc.html');
if (!existsSync(html)) throw new Error('Expected webxdc.html in dist-webxdc');
renameSync(html, join(dist, 'index.html'));
const assets = {};
function addDir(dir) {
  for (const e of readdirSync(dir, { withFileTypes: true })) {
    const full = join(dir, e.name);
    if (e.isDirectory()) addDir(full);
    else {
      const name = relative(dist, full).replaceAll('\\', '/');
      // Vite's public/ includes external-site extras; only ship relevant runtime files.
      if (name.endsWith('.map') || name === '.bundle-report.json') continue;
      assets[name] = new Uint8Array(readFileSync(full));
    }
  }
}
addDir(dist);
assets['manifest.toml'] = strToU8('name = "Call of Blocky - Offline"\nsource_code_url = "https://github.com/Potrock/blockyard"\n');
assets['icon.png'] = new Uint8Array(readFileSync(join(root, 'public', 'icon-512.png')));
const out = join(root, 'Call_of_Blocky_Offline.xdc');
writeFileSync(out, zipSync(assets, { level: 6 }));
const kb = (readFileSync(out).length / 1048576).toFixed(1);
console.log(`\nCreated ${out} (${kb} MiB) — experimental single-player WebXDC.`);
