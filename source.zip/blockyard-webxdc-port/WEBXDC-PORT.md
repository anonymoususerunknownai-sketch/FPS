# Call of Blocky: authentic engine WebXDC experiment

This is **a source-code integration**, not a successfully compiled/verified playable XDC. It preserves the original MIT-licensed Blockyard Rust voxel engine, real Three.js renderer, Call of Blocky `.glb` models, weapons, maps and server game simulation with AI bots. It replaces the online WebSocket transport with an in-browser worker that runs the original `GameHost` from `src/platform/host/game.ts`. There are no AI-generated placeholder graphics.

## Build on Windows

Install Node.js >= 22, Git if desired, and [Rust](https://rustup.rs/) (stable). In PowerShell in this directory:

```powershell
rustup target add wasm32-unknown-unknown
npm install
npm run build:webxdc
```

The generated `Call_of_Blocky_Offline.xdc` is a ZIP-format WebXDC package. Send it to a Delta Chat conversation and tap Start. For desktop testing, run `npx vite preview --outDir dist-webxdc` and open the preview address with `/index.html` (after build).

## Current limitations

- Single player only; enemies use original bots. No networking across devices.
- Browser worker starts a local version of the original game server; it does not use an external server.
- Not yet built or runtime-tested in Delta Chat on iOS; could require code changes for WebGL2, module workers, WASM SIMD, or iPhone memory usage.
- The uploaded source ZIP contains no `engine/pkg` compiled WASM and no `node_modules`. The creation environment had no Rust compiler and no access to download them, so there is no verified ready-to-play `.xdc` included.
- Cosmetic/account progress and persistent saves from Blockyard's online server are not preserved in this test.
- The Vite build may reveal issues not caught by static checks (such as game model URLs or WebXDC CSP restrictions). The package builder creates a preliminary port for testing, **not a release-quality game**.
- The original upstream project can be recovered via the user's original ZIP. `src/platform/client/link.ts`, `src/platform/client/local-host.worker.ts`, `src/platform/runtime.ts` and the new build files hold the WebXDC edits.

## Attribution

Based on Blockyard by Potrock, licensed MIT; see `LICENSE`. This is an unofficial experimental adapter, not endorsed by Blockyard's author.
